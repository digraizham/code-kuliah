# Lab2 PPw

## Profile

Digra Murtaza Izham - 1313621010
Ilmu Komputer 2021